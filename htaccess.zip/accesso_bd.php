<?php

$mysqli = new mysqli("mysql.hostinger.com.ar", "u374994852_agost", "bgt55bgt", "u374994852_agost");


if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}else{
	//echo "Conexion OK";
}


function conexionBD(){
	$mysqli = new mysqli("mysql.hostinger.com.ar", "u374994852_agost", "bgt55bgt", "u374994852_agost");

	/* check connection */
	if (mysqli_connect_errno()) {
	    printf("Connect failed: %s\n", mysqli_connect_error());
	    exit();
	}else{
		//echo "Conexion OK";
	}

	return $mysqli;
}
?>